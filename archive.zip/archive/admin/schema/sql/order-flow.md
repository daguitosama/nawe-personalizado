# Order Flow

El cliente contacta con su interés en el producto o servicio, se le atiende en what's app y se hace su orden que queda registrada con el modelo de la oferta

Stages
-  Vendiendo
-  Produciendo
-  Entregada

La orden tiene
- cliente
- productos/servicios con costo -> Order Items
- costo total