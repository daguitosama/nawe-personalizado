export type Admin = {
    admin_id: number;
    username: string;
    password_hash: string;
};
