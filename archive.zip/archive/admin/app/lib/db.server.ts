import postgres from "postgres";
const DB_URL = process.env.DB_URL;
if (typeof DB_URL != "string") {
    throw new Error("Env var: $DB_URL is missing");
}

export const sql = postgres(DB_URL);
