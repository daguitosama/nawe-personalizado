import { type ActionFunctionArgs, createCookie, redirect } from "@remix-run/node";
if (typeof process.env.COOKIE_SECRET != "string") {
    throw new Error("Env var: $COOKIE_SECRET is missing");
}
const secret = comma_separated_to_array_of_strings(process.env.COOKIE_SECRET);

export const auth_cookie = createCookie("auth", {
    secrets: secret,
    // 120 days
    maxAge: 60 * 60 * 24 * 120,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
});

export async function get_auth_from_request(request: Request): Promise<string | null> {
    const userId = await auth_cookie.parse(request.headers.get("Cookie"));
    return userId ?? null;
}

export async function set_auth_on_response(response: Response, userId: string): Promise<Response> {
    const header = await auth_cookie.serialize(userId);
    response.headers.append("Set-Cookie", header);
    return response;
}

export async function require_auth_cookie(request: Request) {
    const userId = await get_auth_from_request(request);
    if (!userId) {
        throw redirect("/login", {
            headers: {
                "Set-Cookie": await auth_cookie.serialize("", {
                    maxAge: 0,
                }),
            },
        });
    }
    return userId;
}

export async function redirect_if_logged_in_loader({ request }: ActionFunctionArgs) {
    const userId = await get_auth_from_request(request);
    if (userId) {
        throw redirect("/");
    }
    return null;
}

export async function redirect_with_cleared_cookie(): Promise<Response> {
    return redirect("/", {
        headers: {
            "Set-Cookie": await auth_cookie.serialize(null, {
                expires: new Date(0),
            }),
        },
    });
}

function comma_separated_to_array_of_strings(list: string): string[] {
    return list.split(",").filter((word) => word.length > 0);
}
