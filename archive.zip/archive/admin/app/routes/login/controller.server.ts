import { sql } from "~/lib/db.server";
import bcrypt from "bcryptjs";
export function validate(username: string, password: string) {
    const errors: { username?: string; password?: string } = {};

    if (!username) {
        errors.username = "Username is required.";
    }

    if (!password) {
        errors.password = "Password is required.";
    } else if (password.length < 8) {
        errors.password = "Password must be at least 8 characters.";
    }

    return Object.keys(errors).length ? errors : null;
}
type Login_Credentials_Error = {
    kind: "credentials";
    message: "Invalid Credentials";
};
type Login_DB_Error = {
    kind: "db";
    message: string;
};

type Login_Error = Login_Credentials_Error | Login_DB_Error;
type Login_Result_Success = {
    data: {
        user_id: string | null;
    };
    error: null;
};

type Login_Result_Error = {
    data: null;
    error: Login_Error;
};

type LoginResult = Login_Result_Success | Login_Result_Error;
type Admin = {
    admin_id: number;
    username: string;
    password_hash: string;
};
export async function login(username: string, password: string): Promise<LoginResult> {
    try {
        const adminRows = await sql<Admin[]>`select * from admins where username = ${username};`;
        if (!adminRows.length) {
            return { data: { user_id: null }, error: null };
        }
        const is_valid_password = bcrypt.compare(password, adminRows[0].password_hash);
        if (!is_valid_password) {
            return { data: null, error: { kind: "credentials", message: "Invalid Credentials" } };
        }
        return { data: { user_id: String(adminRows[0].admin_id) }, error: null };
    } catch (error) {
        console.error(error);
        if (error instanceof Error) {
            return { data: null, error: { kind: "db", message: error.message } };
        }
        return { data: null, error: { kind: "db", message: "unknown" } };
    }
}
