import { Form, useActionData } from "@remix-run/react";
import { json, type ActionFunctionArgs, redirect } from "@remix-run/node";
import { redirect_if_logged_in_loader, set_auth_on_response } from "~/lib/auth.server";
import { Logo } from "../../components/Logo";
import { login, validate } from "./controller.server";
// type ActionData = {
//     error: {
//         db_error?: string | null;
//         username?: string | null;
//         password?: string | null;
//     };
// };

export const loader = redirect_if_logged_in_loader;

export async function action({ request }: ActionFunctionArgs) {
    const formData = await request.formData();
    const username = String(formData.get("username") || "");
    const password = String(formData.get("password") || "");

    const errors = validate(username, password);
    if (errors) {
        return json({ ok: false, errors }, 400);
    }

    const log_in_result = await login(username, password);
    if (log_in_result.error) {
        return json({ ok: false, errors: { server_error: log_in_result.error } }, 400);
    }
    if (!log_in_result.data?.user_id) {
        return json({ ok: false, errors: { credentials: "Credenciales invalidas" } }, 400);
    }

    const response = redirect("/");
    return set_auth_on_response(response, log_in_result.data.user_id);
}

export default function LoginRoute() {
    const actionData = useActionData<typeof action>();
    return (
        <div className=''>
            <div className='max-w-[400px] mx-auto px-[30px] mt-[150px]'>
                <div className='flex flex-col items-center gap-6'>
                    <Logo />
                    <h1 className='text-2xl'>Login to dashboard</h1>
                </div>
                {actionData?.error?.auth_error && (
                    <div className='mt-[30px] bg-red-100 text-red-950 border-red-400 border-2 rounded-xl px-[16px] py-[16px] text-sm'>
                        <p>{actionData.error.auth_error}</p>
                    </div>
                )}
                <Form
                    method='post'
                    className='mt-[30px] grid grid-cols-1 gap-[20px]'
                >
                    <div className='grid grid-cols-1 gap-[10px]'>
                        <label
                            htmlFor='username-input'
                            className='px-[6px]'
                        >
                            Username
                        </label>
                        <input
                            type='text'
                            name='username'
                            id='username-input'
                            minLength={3}
                            maxLength={20}
                            pattern='^[a-zA-Z0-9_]+$'
                            title='Username can only include letters, numbers, and underscores. And must be between 3 and 20 characters'
                            className='border border-black/50 rounded-md py-[6px] px-[6px]'
                            required
                        />
                        {actionData?.error?.username && (
                            <div className='mt-[30px] bg-red-100 text-red-950 border-red-400 border-2 rounded-xl px-[16px] py-[16px] text-sm'>
                                <p>{actionData.error.username}</p>
                            </div>
                        )}
                    </div>

                    <div className='grid grid-cols-1 gap-[10px]'>
                        <label
                            htmlFor='password-input'
                            className='px-[6px]'
                        >
                            Password
                        </label>
                        <input
                            type='password'
                            name='password'
                            id='password-input'
                            className='border border-black/50 rounded-md py-[6px] px-[6px]'
                            minLength={8}
                            maxLength={100}
                            required
                        />
                        {actionData?.error?.password && (
                            <div className='mt-[30px] bg-red-100 text-red-950 border-red-400 border-2 rounded-xl px-[16px] py-[16px] text-sm'>
                                <p>{actionData.error.password}</p>
                            </div>
                        )}
                    </div>
                    <div className='pt-[10px]'>
                        <button className='border border-black/50 rounded-md py-[6px] px-[6px] w-full'>
                            Login
                        </button>
                    </div>
                </Form>
            </div>
        </div>
    );
}
